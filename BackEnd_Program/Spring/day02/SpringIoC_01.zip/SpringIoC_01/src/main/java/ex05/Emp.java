package ex05;

public interface Emp {
	void info1();
	void info2();
	void info3();
	void info4();
}
