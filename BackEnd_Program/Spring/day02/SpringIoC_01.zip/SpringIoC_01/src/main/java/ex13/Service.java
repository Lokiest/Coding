package ex13;

public interface Service {
	void test1();
	void test2();
}
