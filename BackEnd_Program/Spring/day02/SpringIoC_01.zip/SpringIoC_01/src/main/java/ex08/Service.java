package ex08;

public interface Service {
	void test1();
}
