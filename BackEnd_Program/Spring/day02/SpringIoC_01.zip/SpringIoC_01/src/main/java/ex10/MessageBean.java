package ex10;

public interface MessageBean {
	public void sayHello();
	public void sayHi(String ... names);
}
