package ex09;

public interface Service {
	void test1();
}
