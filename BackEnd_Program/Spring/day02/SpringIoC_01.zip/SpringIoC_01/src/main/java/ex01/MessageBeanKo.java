package ex01;

public class MessageBeanKo {

	public void sayHello(String name) {
		System.out.println("�ȳ� " + name);
	}
}
