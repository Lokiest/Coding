package ex10;

import java.io.IOException;

public interface Output {
	
	void out(String msg) throws IOException;
}
