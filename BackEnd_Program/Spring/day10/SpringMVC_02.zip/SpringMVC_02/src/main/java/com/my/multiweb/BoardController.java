package com.my.multiweb;

import java.io.File;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.board.model.BoardVO;
import com.board.service.BoardService;
import com.common.CommonUtil;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/board")
@Log4j
public class BoardController {
	
	@Resource(name="boardServiceImpl")
	private BoardService boardService;
	
	@GetMapping("/write")
	public String boardForm() {
		
		return "board/boardWrite";
	}
	
	@Inject
	private CommonUtil util;
	
	@PostMapping("/write")
	public String boardInsert(Model m, HttpServletRequest req, @RequestParam("mfilename") MultipartFile mfilename, @ModelAttribute BoardVO board) {
		log.info("board == " + board);
		//1. 파일 업로드 처리
		ServletContext app = req.getServletContext();
		String upDir = app.getRealPath("/resources/board_upload");
		File dir = new File(upDir);
		if(!dir.exists()) {
			dir.mkdirs();
		}
		if(!mfilename.isEmpty()) {
			String originFname = mfilename.getOriginalFilename();
			long fsize = mfilename.getSize();
			log.info(originFname + " >>> " + fsize);
			
			// 동일 파일명이 서버에 있을 경우 덮어쓰기 방지 위해 랜덤문자열_원본파일명 >> 물리적 파일명 생성
			UUID uuid = UUID.randomUUID();
			String filename = uuid.toString() + "_" + originFname;
			log.info("filename == " + filename);
			
			try {
				mfilename.transferTo(new File(upDir, filename));
				log.info("upDir == " + upDir);
			} catch(Exception e) {
				log.error("board write file upload error "+e);
			}
			
			board.setFilename(filename);
			board.setOriginFilename(originFname);
			board.setFilesize(fsize);
		}
		
		//2. 유효성 체크 (subject, name, passwd) >> redirect "write"
		if(board.getName()==null||board.getSubject()==null||board.getPasswd()==null||
				board.getName().trim().isEmpty()||board.getSubject().trim().isEmpty()||board.getPasswd().trim().isEmpty()) {
			return "redirect:write";
		}
		
		//3. boardService의 insertBoard() 호출
		int n = 0;
		String str = "", loc = "";
		if("write".equals(board.getMode())) {
			n = this.boardService.insertBoard(board);
			str = "글쓰기 ";
			
		} else if("rewrite".equals(board.getMode())) {
			
		} else if("edit".equals(board.getMode())) {
			
		}
		str+=(n>0)?"성공":"실패";
		loc+=(n>0)?"list":"javascript:history.back()";
		
		//4. message, loc 저장
		
		
//		m.addAttribute("message", "test");
//		m.addAttribute("loc", "list");
		//반복되는 부분 컴포넌트 만들어서 처리하기
		
		return util.addMsgLoc(m, str, loc);
	}
	
	@GetMapping("/list")
	public String boardList(Model m) {
		//게시판 목록 가져와서 모델에 저장
		//"boardArr"
		List<BoardVO> boardArr = this.boardService.selectBoardAll(null);
		m.addAttribute("boardArr", boardArr);
		
		return "board/boardList";
	}
	
	
	@GetMapping("/view/{num}")
	public String boardView(Model m, @PathVariable("num") int num) {
		log.info("num===" + num);
		//조회수 증가 처리
		int n = this.boardService.updateReadnum(num);
		
		BoardVO board = this.boardService.selectBoardByIdx(num);
		m.addAttribute("board", board);
		
		return "board/boardView";
	}
}
