package com.board.model;

import lombok.Data;

//페이징 처리 및 검색 기능 모듈화해서 재사용할 수 있도록 하기

@Data
public class PagingVO {
	
	//페이징 처리 관련 프로퍼티
	private int cpage;
	private int pageSize;
	private int totalCount;
	private int pageCount;
	
	//DB에서 레코드 끊어오기 위한 프로퍼티
	private int start;
	private int end;
	
	//페이징 블럭 처리 위한 프로퍼티
	private int pagingBlock=5;
	private int prevBlock;
	private int nextBlock;
	
	//검색 관련
	private String findType;
	private String findKeyword;
	
	//페이징 처리 연산 수행하는 메서드
	public void init() {
		pageCount =(totalCount - 1)/pageSize + 1;
		if(cpage<1) {
			cpage=1;
		}
		if(cpage>pageCount) {
			cpage=pageCount;
		}
		
		start = (cpage-1)*pageSize;
		end = start + (pageSize+1);
		prevBlock = (cpage - 1)/pagingBlock * pagingBlock;
		nextBlock = prevBlock + (pagingBlock + 1);
		
		//페이징 블럭 연산
		
		
	}
	
}
