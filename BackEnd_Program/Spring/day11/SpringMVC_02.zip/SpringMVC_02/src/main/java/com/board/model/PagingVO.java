package com.board.model;

public class PagingVO {

}
